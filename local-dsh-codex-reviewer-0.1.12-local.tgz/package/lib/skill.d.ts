/**
 * Bundled `configure-approval-llm` skill provider.
 *
 * Ships the reviewer-configuration guide with the npm package, so installing
 * the plugin also puts the skill in the catalog (source `bundled`, rank 600,
 * the standard precedence for packaged skill providers). The body lives in
 * `assets/` and is read lazily on `get()`.
 * @module dsh-approval-llm/skill
 */
import type { Context } from '@deepseek-ai/cordis';
/** Register the bundled reviewer-configuration provider on `ctx.skills`. */
export declare function registerSkillProvider(ctx: Context): void;
//# sourceMappingURL=skill.d.ts.map