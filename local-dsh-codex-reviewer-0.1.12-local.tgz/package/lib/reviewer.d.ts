/**
 * The model reviewer: one isolated security-policy request per approval
 * (PLAN-058 §4.5 — the reviewer, never the main agent, holds the full policy),
 * with JSON-framed facts so tool output cannot break structural delimiters,
 * and fail-to-human classification (TIMEOUT / PARSE_ERROR / MODEL_ERROR) on
 * the ESCALATE path.
 * @module dsh-approval-llm/reviewer
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Session } from '@deepseek-ai/dsh-session';
import type { ApprovalLlmConfig, ReviewInput, ReviewerDecision, ReviewerResult, RiskLevel } from './types.ts';
/** Capability-owned timeout code for reviewer requests. */
export declare const APPROVAL_TIMEOUT_CODE = "APPROVAL_LLM_TIMEOUT";
/**
 * Built-in security policy. Kept apart from any main-agent prompt so the
 * requesting agent cannot learn the review rules and tailor its asks.
 */
export declare const DEFAULT_APPROVAL_POLICY: string;
/**
 * Parse and validate the structured decision from reviewer text.
 * @param text - the assembled reviewer text output.
 * @returns the validated decision fields.
 * @throws when the output carries no valid JSON decision.
 */
export declare function parseDecision(text: string): {
    decision: ReviewerDecision;
    riskLevel?: RiskLevel;
    reason?: string;
};
/**
 * Run one review through the reviewer model.
 * @param ctx - context exposing the LLM service.
 * @param session - session whose log supplies the fallback route.
 * @param input - the assembled review facts.
 * @param config - validated policy.
 * @param signal - cancellation from the approval request.
 * @returns a decision, or ESCALATE with a failure classification for fail-to-human.
 */
export declare function reviewRequest(ctx: Context, session: Session, input: ReviewInput, config: ApprovalLlmConfig, signal?: AbortSignal): Promise<ReviewerResult>;
//# sourceMappingURL=reviewer.d.ts.map