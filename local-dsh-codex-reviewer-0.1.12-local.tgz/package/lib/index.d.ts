/**
 * dsh-approval-llm: model-based permission approval for DeepSeek Harness.
 *
 * The plugin answers the `approval/request` waterfall (Codex's
 * approvals_reviewer=auto_review) with a separate reviewer model, but only in
 * the dedicated permission preset (`modePreset`, default `model-approval`):
 * outside that mode every request delegates to the next answerer (the human
 * channel), so model review never front-runs human approval. Inside the mode:
 * a deterministic routing policy decides SAFE_ALLOW / DENY / HUMAN_ONLY up
 * front, the reviewer model decides everything else (ALLOW / DENY / ESCALATE),
 * and model failures and ESCALATE hand the request back to a human via
 * `next()`. Consecutive DENY hits a circuit breaker that also hands off.
 * Model decisions are appended to the session as a user-visible message, so
 * the main chain records why a call was approved or denied.
 * @module dsh-approval-llm
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { PermissionPresetService } from '@deepseek-ai/dsh-permission-presets';
import type { ApprovalLlmConfig } from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        permissionPresets: PermissionPresetService;
    }
}
export declare const name = "dsh-codex-reviewer";
export declare const inject: string[];
export declare const Config: z<ApprovalLlmConfig>;
/**
 * Register the approval answerer and the bundled reviewer-configuration skill.
 * @param ctx - context exposing the LLM, tool-registry, permission-preset, and skills services.
 * @param rawConfig - untrusted plugin configuration, validated by the schema.
 */
export declare function apply(ctx: Context, rawConfig: ApprovalLlmConfig): void;
//# sourceMappingURL=index.d.ts.map